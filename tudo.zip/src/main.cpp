#include "driver.h"

int main(int argc, const char *argv[])
{
    initialize();
    return 0;
}
