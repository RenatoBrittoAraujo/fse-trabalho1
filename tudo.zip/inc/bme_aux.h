#ifndef BME_AUX_H_
#define BME_AUX_H_

void bme_conecta();
float bme_temperatura_atual();

#endif