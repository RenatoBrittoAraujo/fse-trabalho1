#ifndef POTENCIOMETRO_H_
#define POTENCIOMETRO_H_

void potenciometro_controle();

#endif