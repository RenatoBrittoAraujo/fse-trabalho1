#ifndef DRIVER_H_
#define DRIVER_H_

void app_inicia();
void kill(int exit_code = 0);

#endif