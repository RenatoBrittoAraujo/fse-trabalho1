#ifndef GPIO_H_
#define GPIO_H_

void gpio_desliga_resistencia();
void gpio_desliga_ventoinha();
void gpio_controle_temperatura(int intensidade);

#endif